package compiler.Parser.Grammar;

public class Statement {
    int tabIndex;
    public Statement(int tabIndex){
        this.tabIndex = tabIndex;
    }
}
